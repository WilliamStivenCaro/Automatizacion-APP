# OMNI.PRO  Automatización de App Móvil Wikipedia

### Índice

* [Instrucciones de instalación y ejecución](#instrucciones-de-instalación-y-ejecución)

* [Tecnologías utilizadas](#tecnologías-utilizadas)

* [Justificación de elección de la APP](#justificación-de-elección-de-la-app)


---

## Instrucciones de instalación y ejecución

## Java JDK (versión 8 o superior).
<img src="https://i.blogs.es/8d2420/650_1000_java/1366_2000.png" alt="java" width="200" height="200" />

## Maven como herramienta de construcción.

<img src="https://fossa.com/blog/content/images/2022/02/maven.png" alt="mvn" width="400" height="200" />

## Node.js y npm para instalar Appium.
Appium: Instálalo globalmente con el comando:
```

npm install -g appium

```

## IDE como IntelliJ IDEA o Eclipse.
## Plugin de Cucumber Instalado
## Dispositivo móvil o emulador/simulador configurado. Android Studio
## Variables de entorno configuradas de:
Java, Maven, Android

---

## ¿Cómo Ejecutar?

Para la ejecución debemos de seguir los siguientes pasos:

1. En la terminal del proyecto ejecuta este comando para hacer el clean build:

        $ mvn clean

2. Luego, ejecutamos con el siguiente comando por la terminal del proyecto:

         $ mvn test

Nota: si quieres ejecutar de una forma diferente, como por runner puedes dar click en
Edit Configurations, creas un nuevo JUnit, seleccionas el runner a ejecutar

---

## ¿Cómo Generar el Reporte de Serenity?

Al finalizar la ejecución puedes ejecutar el siguiente comando por la terminal del proyecto:

    $ mvn serenity:aggregate

Nota: cuando ejecutes el comando con `serenity:aggregate`, podrás ver el reporte de las pruebas en la ruta:
`target/site/serenity/index.html`.



```
configAppium.properties 

platformName=   Especifica la plataforma del sistema operativo en la que se ejecutarán las pruebas.
platformVersion= Define la versión del sistema operativo de la plataforma especificada.       
udid=emulator- Especifica qué dispositivo o emulador usar para las pruebas. En este caso, emulator-5554 es el nombre de un emulador Android que puedes ver al ejecutar adb devices.
#app= Define la ruta al archivo de la aplicación (APK para Android) que se instalará y probará.
appPackage= Indica a Appium qué aplicación abrir. El appPackage es el identificador único de la app
appActivity= Define la actividad principal de la aplicación que Appium iniciará.
automationName= Especifica el nombre del controlador de automatización que Appium usará.
autoGrantPermissions= Configura si Appium otorgará automáticamente los permisos solicitados por la app durante la instalación o ejecución.
serverUrl= Define la URL del servidor de Appium donde se ejecutará la sesión de automatización.
___________________________



```



---

## Tecnologías utilizadas

## JUnit: 
Framework de pruebas unitarias para Java, utilizado como ejecutor de pruebas en este proyecto.
## Serenity BDD: 
Biblioteca que facilita la escritura de pruebas de aceptación automatizadas con informes detallados y documentación viva. Soporta Cucumber y JUnit, y se integra con Appium para pruebas móviles.
[https://serenity-bdd.info/documentation/](https://serenity-bdd.info/documentation/)
## Cucumber: 
Herramienta para escribir pruebas en estilo BDD usando el lenguaje Gherkin, que permite definir escenarios en un formato legible para humanos.
[https://cucumber.io/](https://cucumber.io/)
## Appium: 
Herramienta de código abierto para automatizar aplicaciones móviles en Android e iOS, compatible con Serenity BDD.

## Lenguaje de Programacion: 
Java

---

=======


## Estructura Del Proyecto

La estructura de este proyecto usa el patron de diseño Screenplay y se encuentra implementada de la siguiente manera:


        + models
            Clases relacionadas con el modelo de dominio y sus respectivos builder cuando es necesario
        + tasks
            Clases que representan tareas que realiza el actor a nivel de proceso de negocio
        + userinterfaces
            Page Objects y Page Elements. Mapean los objetos de la interfaz de usuario
        + questions
            Objetos usados para consultar acerca del estado de la aplicación
        + utils
            Clases de utilidad
        + runners
            Clases que permiten ejecutar los tests
        + steps
            Clases que mapean las líneas Gherkin a código java
        + features
            La representación de las historias en lenguaje Gherkin
        * target >> site >> serenity
        Reporte detallado de las pruebas Automatizadas con Imagenes del paso a paso



## Justificación de elección de la APP

1. Wikipedia es una App con flujos de búsqueda, navegación entre artículos, Login
No requiere autenticación obligatoria

2. Wikipedia tiene versiones móviles (Android/iOS) lo que permite probar:

Interacciones  (scrolls, swipes, rotación, notificaciones, manejo de permisos)
Rendimiento en diferentes dispositivos.
Compatibilidad con múltiples sistemas operativos.

3. Es una App que tiene una variedad de funcionalidades y permite realizar diferentes casuisticas de pruebas
con la automatización 

