package com.app.wikipedia.utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.URL;

public class AppiumTest {
    public static void main(String[] args) throws Exception {
        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("appium:platformName", "Android");
        caps.setCapability("appium:platformVersion", "11");
        caps.setCapability("appium:udid", "emulator-5554");

        caps.setCapability("appium:app", "C:\\Users\\Lenovo\\Downloads\\Documents\\William\\Proyectos de Automatizacion\\app\\com.app.wikipedia\\src\\test\\resources\\apps\\Wikipedia.apk");
        caps.setCapability("appium:appPackage", "org.wikipedia");
        caps.setCapability("appium:appActivity", "org.wikipedia.main.MainActivity");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:autoGrantPermissions", true);


        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), caps);
        System.out.println("Sesión iniciada correctamente");

        String xmlSource = ((AppiumDriver) driver).getPageSource();
        System.out.println(xmlSource);
        Serenity.recordReportData().withTitle("xmlSource").andContents(xmlSource);
        driver.quit();
    }
}