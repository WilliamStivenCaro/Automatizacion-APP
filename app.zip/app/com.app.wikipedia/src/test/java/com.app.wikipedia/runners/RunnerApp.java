package com.app.wikipedia.runners;

import com.app.wikipedia.utils.runners.BeforeSuite;
import com.app.wikipedia.utils.runners.PersonalizedRunner;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

import java.io.IOException;


@RunWith(PersonalizedRunner.class)
 @CucumberOptions(features = "src/test/resources/features/wikipedia.feature",
        glue = {"com.app.wikipedia.steps"},
   tags = "@App",
        snippets = CucumberOptions.SnippetType.CAMELCASE)



public class RunnerApp {

 public static String feature = "wikipedia.feature";

@BeforeSuite
 public static void test() throws InvalidFormatException, IOException, com.ibm.icu.impl.InvalidFormatException {


}
}