package com.app.wikipedia.steps;


import com.app.wikipedia.questions.InicioSesion;
import com.app.wikipedia.questions.Navegacion;
import com.app.wikipedia.tasks.MobileAutomationTest;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;
import net.serenitybdd.screenplay.actions.Switch;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.ensure.Ensure;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.net.URL;

import static com.app.wikipedia.interactions.Buscar.buscar;
import static com.app.wikipedia.interactions.Login.login;
import static com.app.wikipedia.interactions.Navegacion.navegacion;
import static com.app.wikipedia.models.datatables.Data.getCampo1;
import static com.app.wikipedia.tasks.APP.clickBotonContinuar;
import static com.app.wikipedia.tasks.APP.clickSkipButton;
import static com.app.wikipedia.tasks.IniciarSesion.clickMoroOptions;
import static com.app.wikipedia.tasks.IniciarSesion.testXML;
import static com.app.wikipedia.userInterface.UserInterface.*;
import static com.app.wikipedia.utils.appium.Capabilities.configurarCapacidades;
import static com.app.wikipedia.utils.properties.GetValueProperties.getserverUrl;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class PasosWikipedia {
    private static final Logger LOGGER = LoggerFactory.getLogger(PasosWikipedia.class);

    public String actor = System.getProperty("user.name");
    private static AppiumDriver driver;

    @Before
    public void sedStage() {
        try {
            OnStage.setTheStage(new OnlineCast());
            DesiredCapabilities caps = configurarCapacidades();
            driver = new AndroidDriver(new URL(getserverUrl()), caps);

        } catch (MalformedURLException e) {
            LOGGER.error("Error al conectar con el servidor Appium", e);
            throw new RuntimeException("Error en la URL del servidor Appium", e);
        }
    }


    @Given("Que Ingreso a la APP de Wikipedia")
    public void queIngresoALaAppWikipedia() {
        LOGGER.info("Ingresando a la app de Wikipedia");

        OnStage.theActorCalled(actor).whoCan(BrowseTheWeb.with(driver));

    }


    @When("Inicia sesión con el nombre de usuario y el password")
    public void iniciaSesiónConElNombreDeUsuario(DataTable data) {
        LOGGER.info("Inicia sesión con usuario y contraseña: ");
        theActorInTheSpotlight().attemptsTo(login(data));
    }


    @Then("Se visualiza la pantalla de inicio")
    public void seVisualizaLaPantallaInicio() {
        LOGGER.info("Validando que se visualice la pantalla de inicio");

        theActorInTheSpotlight().attemptsTo(
                Ensure.that(InicioSesion.value()).isEqualTo("Join Wikipedia")
        );
    }


    @When("Se busca el artículo")
    public void buscarArticulo(DataTable data) {
        LOGGER.info("Se busca el articulo");
        theActorInTheSpotlight().attemptsTo(buscar(data));
    }


    @Then("Se visualizan los resultados de búsqueda que contengan el artículo")
    public void deberiaVerResultadosBusqueda(DataTable data) {
        LOGGER.info("Ver resultados de búsqueda");

        String texto = DYNAMIC_SEARCH_BY_CONTAIN_TEXT(getCampo1(data)).resolveFor(theActorInTheSpotlight()).getText();
        theActorInTheSpotlight().attemptsTo(
                Ensure.that(texto).isEqualTo(getCampo1(data))
        );
    }


    @When("Navego en la APP Wikipedia")
    public void navegoAPP() {
        LOGGER.info("Navego en la APP Wikipedia");
        theActorInTheSpotlight().attemptsTo(navegacion());
    }



    @When("Se valida bajar el subir")
    public void subirScroll() {
        LOGGER.info("Se valida bajar el Scroll");

        theActorInTheSpotlight().attemptsTo(
                clickBotonContinuar(),
                Scroll.to(CONTINUE_BUTTON).andAlignToTop()
                );


    }

    @When("Se valida Mover Interface")
    public void moverInterface() {
        LOGGER.info("Se valida Mover Interface");
        theActorInTheSpotlight().attemptsTo(MoveMouse.to(SKIP_BUTTON));
    }


    @When("Se valida Aceptar alert")
    public void aceptarAlert() {
        LOGGER.info("Se valida Aceptar alert");
        theActorInTheSpotlight().attemptsTo(
                clickBotonContinuar(),
                clickSkipButton(),
                clickMoroOptions(),
                Click.on(LOGIN),
                Click.on(CREATE_ACCOUNT),
                Switch.toAlert().andAccept()

        );
    }


}
