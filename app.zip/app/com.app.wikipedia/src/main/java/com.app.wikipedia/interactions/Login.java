package com.app.wikipedia.interactions;

import io.cucumber.datatable.DataTable;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;

import static com.app.wikipedia.models.datatables.Data.getCampo1;
import static com.app.wikipedia.models.datatables.Data.getCampo2;
import static com.app.wikipedia.tasks.APP.clickBotonContinuar;
import static com.app.wikipedia.tasks.APP.clickSkipButton;
import static com.app.wikipedia.tasks.IniciarSesion.clickMoroOptions;
import static com.app.wikipedia.tasks.IniciarSesion.loginWikipedia;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class Login implements Interaction {

    private final DataTable data;
    private final String campo1;
    private final String campo2;


    public Login(DataTable data) {
        this.data = data;
        this.campo1 = getCampo1(data);
        this.campo2 = getCampo2(data);
    }

    @Override
    public <T extends Actor> void performAs(T t) {

        theActorInTheSpotlight().attemptsTo(
        clickBotonContinuar(),
                clickSkipButton(),
                clickMoroOptions(),
                loginWikipedia(campo1,campo2)

        );
    }

    public static Login login(DataTable data) {
        return Tasks.instrumented(Login.class, data);
    }


}
