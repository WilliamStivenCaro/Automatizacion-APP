package com.app.wikipedia.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;

import static com.app.wikipedia.tasks.APP.clickBotonContinuar;
import static com.app.wikipedia.tasks.APP.clickSkipButton;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class Navegacion implements Interaction {



    @Override
    public <T extends Actor> void performAs(T t) {

        theActorInTheSpotlight().attemptsTo(
                clickBotonContinuar(),
                clickSkipButton()
        );
    }

    public static Navegacion navegacion() {
        return Tasks.instrumented(Navegacion.class);
    }


}
