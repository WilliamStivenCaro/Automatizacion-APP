package com.app.wikipedia.interactions;

import io.cucumber.datatable.DataTable;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;

import static com.app.wikipedia.models.datatables.Data.getCampo1;
import static com.app.wikipedia.tasks.APP.clickBotonContinuar;
import static com.app.wikipedia.tasks.APP.clickSkipButton;
import static com.app.wikipedia.tasks.Buscar.busqueda;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;



public class Buscar implements Interaction {

    private final DataTable data;
    private final String campo1;



    public Buscar(DataTable data) {
        this.data = data;
        this.campo1 = getCampo1(data);

    }

    @Override
    public <T extends Actor> void performAs(T t) {

        theActorInTheSpotlight().attemptsTo(
        clickBotonContinuar(),
                clickSkipButton(),
                busqueda(campo1)

        );
    }

    public static Buscar buscar(DataTable data) {
        return Tasks.instrumented(Buscar.class, data);
    }


}
