package com.app.wikipedia.models.datatables;

import io.cucumber.datatable.DataTable;


public class Data {

    private static String idCaso;

    private static String campo1;
    private static String campo2;



    public static String getIdCaso(DataTable data) {

        idCaso = data.cell(1, 0);
        return idCaso;
    }



    public static String getCampo1(DataTable data) {

        campo1 = data.cell(1, 1);

        return campo1;
    }

    public static String getCampo2(DataTable data) {

        campo2 = data.cell(1, 2);

        return campo2;
    }

    }



