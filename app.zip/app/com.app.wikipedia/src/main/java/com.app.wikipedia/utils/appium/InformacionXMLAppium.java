package com.app.wikipedia.utils.appium;


import io.appium.java_client.AppiumDriver;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class InformacionXMLAppium {

    private static final Logger LOGGER = LoggerFactory.getLogger(InformacionXMLAppium.class);
    private static AppiumDriver driver;

    public static String informacionXMLAppium(Actor actor) {


        String xmlSource = BrowseTheWeb.as(actor).getDriver().getPageSource();
        LOGGER.info("Fuente XML inicial de la aplicación:\n{}", xmlSource);

        // Registrar en el reporte de Serenity
        Serenity.recordReportData()
                .withTitle("Estado Inicial de la Aplicación")
                .andContents(xmlSource);

        return xmlSource;
    }


}
