package com.app.wikipedia.utils.appium;

import org.openqa.selenium.remote.DesiredCapabilities;

import static com.app.wikipedia.utils.properties.GetValueProperties.*;

public class Capabilities {


    public static DesiredCapabilities configurarCapacidades() {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("appium:platformName", getplatformName());
        caps.setCapability("appium:platformVersion", getplatformVersion());
        caps.setCapability("appium:udid", getudid());
        caps.setCapability("appium:appPackage", geturlappPackage());
        caps.setCapability("appium:appActivity", getappActivity());
        caps.setCapability("appium:automationName", getautomationName());
        caps.setCapability("appium:autoGrantPermissions", getautoGrantPermissions());
        return caps;
    }



}
