package com.app.wikipedia.utils.properties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadProjectProperties {

    @SuppressWarnings("unused")
    public static String getValueProperties(String variable) throws IOException {

        String result = "", propFileName = "";
        InputStream inputStream = null;
        Properties prop = null;

        try {
            propFileName = "configAppium.properties";
            prop = new Properties();
            inputStream = new FileInputStream(propFileName);
            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("Archivo de Propiedades '" + propFileName + "' no encontrado.");
            }

            result = prop.getProperty(variable);

        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            inputStream.close();
        }

        return result;
    }

}

