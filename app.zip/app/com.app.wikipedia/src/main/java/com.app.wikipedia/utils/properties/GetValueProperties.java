package com.app.wikipedia.utils.properties;

import java.io.IOException;

import static com.app.wikipedia.utils.properties.ReadProjectProperties.getValueProperties;

public class GetValueProperties {

    private static String platformName = "";
    private static String platformVersion = "";
    private static String udid = "";
    private static String app = "";
    private static String appPackage= "";
    private static String appActivity= "";
    private static String automationName= "";
    private static String autoGrantPermissions="";
    private static String serverUrl="";


    public static String getplatformName() {
        try {
            platformName = getValueProperties("platformName");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return platformName;
    }
    public static String getplatformVersion() {
        try {
            platformVersion = getValueProperties("platformVersion");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return platformVersion;
    }
    public static String getudid() {
        try {
            udid = getValueProperties("udid");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return udid;
    }


    public static String getapp() {
        try {
            app = getValueProperties("app");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return app;
    }
    public static String geturlappPackage() {
        try {
            appPackage = getValueProperties("appPackage");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return appPackage;
    }
    public static String getappActivity() {
        try {
            appActivity = getValueProperties("appActivity");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return appActivity;
    }
    public static String getautomationName() {
        try {
            automationName = getValueProperties("automationName");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return automationName;
    }

    public static String getautoGrantPermissions() {
        try {
            autoGrantPermissions = getValueProperties("autoGrantPermissions");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return autoGrantPermissions;
    }
    public static String getserverUrl() {
        try {
            serverUrl = getValueProperties("serverUrl");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return serverUrl;
    }
}
