package com.app.wikipedia.userInterface;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

public class UserInterface extends PageObject {


    public static final Target SKIP_BUTTON = Target.the("Skip button")
            .located(AppiumBy.id("org.wikipedia:id/fragment_onboarding_skip_button"));

    public static final Target CONTINUE_BUTTON = Target.the("Continue button")
            .located(AppiumBy.id("org.wikipedia:id/fragment_onboarding_forward_button"));

    public static final Target MORE_OPTIONS_BUTTON = Target
            .the("More options")
            .located(AppiumBy.id("org.wikipedia:id/nav_more_container"));


    public static final Target LOGIN = Target
            .the("Botón de login/join")
            .located(AppiumBy.id("org.wikipedia:id/main_drawer_login_button"));

    public static final Target CREATE_ACCOUNT = Target
            .the("Botón para iniciar sesión")
            .located(AppiumBy.id("org.wikipedia:id/create_account_login_button"));


    public static final Target USERNAME_INPUT = Target
            .the("User Input")
            .located(AppiumBy.id("//android.widget.LinearLayout[@resource-id='org.wikipedia:id/login_username_text']//android.widget.EditText"));

    public static final Target PASSWORD_INPUT = Target
            .the("Password Input")
            .located(AppiumBy.id("org.wikipedia:id/login_password_input"));

    public static final Target LOGIN_BUTTON = Target
            .the("Login Button")
            .located(AppiumBy.id("org.wikipedia:id/login_button"));

    public static final Target JOIN_WIKIPEDIA = Target
            .the("Join Wikipedia")
            .located(AppiumBy.id("org.wikipedia:id/login_create_account_button"));

    public static final Target SEARCH_CONTAINER = Target
            .the("Search container")
            .located(By.xpath("//*[@resource-id='org.wikipedia:id/search_container']"));



    public static Target DYNAMIC_SEARCH_BY_CONTAIN_TEXT(String text) {
        return Target.the("Dynamic search by Contain text Select " + text + "")
                .located(AppiumBy.xpath("//android.widget.TextView[contains(@text, '" + text + "')]"));
    }




    public static final Target SEARCH_INPUT_FIELD = Target.the("Search input field")
            .located(AppiumBy.id("org.wikipedia:id/search_src_text"));



    public static final Target LANGUAGE_LIST = Target.the("Language list")
            .located(AppiumBy.id("org.wikipedia:id/languagesList"));

    public UserInterface() {
        PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
    }
}