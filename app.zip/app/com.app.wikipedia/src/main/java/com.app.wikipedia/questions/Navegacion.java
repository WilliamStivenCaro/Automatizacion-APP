package com.app.wikipedia.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static com.app.wikipedia.userInterface.UserInterface.LANGUAGE_LIST;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class Navegacion implements Question<String> {

    private static String mensaje;
    private static String value;


    public static Navegacion value() {
        return new Navegacion();
    }

    @Override
    public String answeredBy(Actor actor) {
        mensaje = LANGUAGE_LIST.resolveFor(theActorInTheSpotlight()).getText();

        return mensaje;
    }





}
