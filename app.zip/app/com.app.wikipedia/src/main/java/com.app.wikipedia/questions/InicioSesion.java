package com.app.wikipedia.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static com.app.wikipedia.userInterface.UserInterface.JOIN_WIKIPEDIA;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class InicioSesion implements Question<String> {

    private static String mensaje;
    private static String value;


    public static InicioSesion value() {
        return new InicioSesion();
    }

    @Override
    public String answeredBy(Actor actor) {
        mensaje = JOIN_WIKIPEDIA.resolveFor(theActorInTheSpotlight()).getText();

        return mensaje;
    }





}
