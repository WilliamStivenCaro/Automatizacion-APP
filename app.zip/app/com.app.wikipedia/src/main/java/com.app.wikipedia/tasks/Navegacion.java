package com.app.wikipedia.tasks;


import net.serenitybdd.screenplay.Task;


public class Navegacion {

    public static Task flujo() {
          return Task.where("{0} Flujos de la APP"

                );


        }


}
