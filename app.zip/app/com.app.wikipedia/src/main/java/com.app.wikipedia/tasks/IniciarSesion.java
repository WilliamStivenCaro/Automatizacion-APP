package com.app.wikipedia.tasks;


import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import static com.app.wikipedia.userInterface.UserInterface.*;
import static com.app.wikipedia.utils.appium.InformacionXMLAppium.informacionXMLAppium;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class IniciarSesion {

    public static Task clickBotonContinuar() {
          return Task.where("{0} click Boton Continuar",
               Click.on(CONTINUE_BUTTON),
                  Click.on(CONTINUE_BUTTON)
                );


        }

    public static Task clickSkipButton() {


        return Task.where("{0} click en Skip Button",
               Click.on(SKIP_BUTTON)
              );
    }

    public static Task clickMoroOptions() {


        return Task.where("{0} click more options",
                Click.on(MORE_OPTIONS_BUTTON)
        );
    }



    public static Task loginWikipedia(String username, String password) {

        return Task.where("{0} enters username '#username' and password '#password",
                Click.on(LOGIN),
                Click.on(CREATE_ACCOUNT)
           //     Enter.theValue(username).into(USERNAME_INPUT)
          //  Enter.theValue(password).into(PASSWORD_INPUT),
           //     Click.on(LOGIN_BUTTON)
        );
    }

    public static Task testXML() {
        informacionXMLAppium(theActorInTheSpotlight());

        return Task.where("{0} Test xml"

        );
    }


}
