package com.app.wikipedia.tasks;


import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;

import static com.app.wikipedia.userInterface.UserInterface.CONTINUE_BUTTON;
import static com.app.wikipedia.userInterface.UserInterface.SKIP_BUTTON;
import static com.app.wikipedia.utils.appium.InformacionXMLAppium.informacionXMLAppium;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;


public class APP {

    public static Task clickBotonContinuar() {
          return Task.where("{0} click Boton Continuar",
               Click.on(CONTINUE_BUTTON),
                  Click.on(CONTINUE_BUTTON)
                );


        }

    public static Task clickSkipButton() {


        return Task.where("{0} click en Skip Button",
               Click.on(SKIP_BUTTON)
              );
    }



    public static Task testXML() {
        informacionXMLAppium(theActorInTheSpotlight());

        return Task.where("{0} Test xml"

        );
    }


}
