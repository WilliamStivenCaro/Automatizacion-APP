package com.app.wikipedia.tasks;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.webdriver.WebDriverFacade;
import org.openqa.selenium.WebDriver;

import java.time.Duration;

public class MobileAutomationTest {


    public static class MobileUser {
        public static Actor named(String actorName, AppiumDriver driver) {
            return Actor.named(actorName)
                    .whoCan(BrowseTheWeb.with(driver));
        }
    }



    public static class ScrollDown implements Task {
        @Override
        public <T extends Actor> void performAs(T actor) {
            AppiumDriver driver = getAppiumDriver(actor);
            int startX = driver.manage().window().getSize().width / 2;
            int startY = (int) (driver.manage().window().getSize().height * 0.8);
            int endY = (int) (driver.manage().window().getSize().height * 0.2);

            new TouchAction<>((PerformsTouchActions) driver)
                    .press(PointOption.point(startX, startY))
                    .waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
                    .moveTo(PointOption.point(startX, endY))
                    .release()
                    .perform();
        }

        public static ScrollDown onScreen() {
            return new ScrollDown();
        }
    }


    public static class SwipeHorizontal implements Task {
        private final boolean leftToRight;

        public SwipeHorizontal(boolean leftToRight) {
            this.leftToRight = leftToRight;
        }

        @Override
        public <T extends Actor> void performAs(T actor) {
            AppiumDriver driver = getAppiumDriver(actor);
            int startY = driver.manage().window().getSize().height / 2;
            int startX = leftToRight ?
                    (int) (driver.manage().window().getSize().width * 0.8) :
                    (int) (driver.manage().window().getSize().width * 0.2);
            int endX = leftToRight ?
                    (int) (driver.manage().window().getSize().width * 0.2) :
                    (int) (driver.manage().window().getSize().width * 0.8);

            new TouchAction<>((PerformsTouchActions) driver)
                    .press(PointOption.point(startX, startY))
                    .waitAction(WaitOptions.waitOptions(Duration.ofMillis(500)))
                    .moveTo(PointOption.point(endX, startY))
                    .release()
                    .perform();
        }

        public static SwipeHorizontal leftToRight() {
            return new SwipeHorizontal(true);
        }

        public static SwipeHorizontal rightToLeft() {
            return new SwipeHorizontal(false);
        }
    }



    public static class AcceptPermission implements Task {
        private final Target permissionButton;

        public AcceptPermission(Target permissionButton) {
            this.permissionButton = permissionButton;
        }

        @Override
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(Click.on(permissionButton));
        }

        public static AcceptPermission forButton(Target permissionButton) {
            return new AcceptPermission(permissionButton);
        }
    }



    private static AppiumDriver getAppiumDriver(Actor actor) {
        return (AppiumDriver) ((WebDriverFacade) actor.abilityTo(BrowseTheWeb.class).getDriver()).getProxiedDriver();
    }
}