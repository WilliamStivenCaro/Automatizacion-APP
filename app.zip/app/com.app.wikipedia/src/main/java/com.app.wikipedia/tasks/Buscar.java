package com.app.wikipedia.tasks;


import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.app.wikipedia.userInterface.UserInterface.SEARCH_CONTAINER;
import static com.app.wikipedia.userInterface.UserInterface.SEARCH_INPUT_FIELD;


public class Buscar {

    public static Task busqueda(String articulo) {
          return Task.where("{0} buscar artículo",
                  Click.on(SEARCH_CONTAINER),
                  Enter.theValue(articulo).into(SEARCH_INPUT_FIELD)
                );


        }




}
